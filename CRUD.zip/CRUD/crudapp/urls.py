from django.urls import path
from . import  views

urlpatterns = [
    path('',views.Home.as_view(),name='home'),
    path('createaccount/',views.CreateAccount.as_view(),name='CreateAccount'),
    path('login/',views.UserLogin.as_view(),name='login'),
    path('logout/',views.User_logout.as_view(),name='logout'),
    path('userdata<int:id>/',views.UserProfile_Data.as_view(),name='USERDATA'),
    path('deldata<int:id>/',views.Delete_Account.as_view(),name='del'),

    path('userall/',views.AllUserData.as_view(),name='alluser'),
  
  

]